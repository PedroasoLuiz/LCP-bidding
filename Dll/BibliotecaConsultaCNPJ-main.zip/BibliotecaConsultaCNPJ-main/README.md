# Biblioteca para consulta de CNPJ no site da Receita Federal
O post Biblioteca para consulta de CNPJ no site da Receita Federal demonstra como implementar e como utilizar uma biblioteca para consultar um CNPJ no site da Receita Federal.
